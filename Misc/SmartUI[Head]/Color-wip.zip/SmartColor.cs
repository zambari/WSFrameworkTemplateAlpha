﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[System.Serializable]
public class SmartColor 
{
     public static void RestoreDefaultPresets()
    {
        presets = new List<SmartColorPreset>();

        AddPreset("custom", Color.white);
        AddPreset("white", Color.white);
        AddPreset("black", Color.black);
        AddPreset("red", Color.red);
        AddPreset("blue", Color.blue);
        AddPreset("green", Color.green);
    }



    public enum ColorModes { preset, custom }
    public enum ColorTargets { image, text }
    public enum FadeMode { NoFade, ToTransparent, ToBlack, ToWhite }
  //  public FadeMode fadeMode;
//    public ColorTargets colorTarget;
    public Color color = Color.gray;// { get;set;}	

    public static string[] presetNames;
    public static List<SmartColorPreset> presets;
    public int selectedPreset;

    
    public static void AddPreset(string name, Color colorValue)
    {
        presets.Add(new SmartColorPreset(name, colorValue));
        presetNames = new string[presets.Count];
        for (int i = 0; i < presets.Count; i++)
        {
            presetNames[i] = presets[i].presetName;
        }
    }

    public static void CheckDefaults()
    {
        if (presets == null)
        {
            RestoreDefaultPresets();
        }
    }
    
 public static Color GetColorPreset (int presetIndex)
 {
	    if (presetIndex > 0 && presets != null && presets.Count > presetIndex)
        {
           return presets[presetIndex].color;
        }
		Debug.Log("invalid color");
		return Color.red;
 }
    Color GetColor(int presetIndex)
    {
        Color thisColor = color;
        if (presetIndex > 0 && presets != null && presets.Count > presetIndex)
        {
            if (selectedPreset >= presets.Count) selectedPreset = 0;
            thisColor = GetColorPreset(selectedPreset);
        }
        return thisColor;
    }
}
[System.Serializable]
public class SmartColorPreset
{
    public string presetName = "unnamed";
    public Color color = Color.gray;
    public SmartColorPreset(string name, Color colorValue)
    {
        color = colorValue;
        presetName = name;
    }
}
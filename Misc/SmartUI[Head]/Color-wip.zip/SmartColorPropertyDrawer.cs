﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomPropertyDrawer(typeof(SmartColor))]
public class SmartColorDrawer : PropertyDrawer
{
    SerializedProperty color;
    SerializedProperty selectedPreset;

    void CheckProperties(SerializedProperty property)
    {
        if (color == null) color = property.FindPropertyRelative("color");
        if (selectedPreset == null) selectedPreset = property.FindPropertyRelative("selectedPreset");
        SmartColor.CheckDefaults();
    }
    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        EditorGUI.BeginProperty(position, label, property);
        CheckProperties(property);
        EditorGUILayout.PropertyField(color);
        GUILayout.Space(10);
//        selectedPreset.intValue = GUILayout.Toolbar(selectedPreset.intValue, SmartColor.presetNames);
  //      if (selectedPreset.intValue!=0) color.colorValue=SmartColor.GetColorPreset(selectedPreset.intValue); // diallow custom changes
		EditorGUILayout.Space();
        EditorGUI.EndProperty();
        }

    }
